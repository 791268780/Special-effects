Copyright (C) 2010-2014 QQPR.com
All Rights Reserved


      Title: ASCII Animator
    Version: 2.0
    Website: http://www.qqpr.com
    Support: pr@qqpr.com
    Release: Freeware
   Requires: Win98/NT4/2000/XP/Vista/7/8


Description:
============

    ASCII Animator is a unique, funny and free software to 
    convert GIF image to animated ASCII art. 
    
    First, ASCII Animator extracts GIF image into frames, 
    then converts each frames to ASCII art, 
    and encodes the ASCII art into a new animated ASCII art GIF image.


Installation:
=============

    To install simply run ASCIIAnimator.exe


Requirements:
=============

    Win98/NT4/2000/XP/Vista/7/8
    ASCII Animator needs Microsoft .NET Framework 2.0 or later.


Contact/Support:
================

    Email: pr@qqpr.com
    WWW:   http://www.qqpr.com
